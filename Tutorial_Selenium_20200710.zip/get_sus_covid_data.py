from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

firefoxprefs = webdriver.FirefoxProfile()
firefoxprefs.set_preference('browser.helperApps.neverAsk.saveToDisk','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
firefoxprefs.set_preference('browser.download.manager.showWhenStarting',False)
firefoxprefs.set_preference('browser.download.dir','D:\\Users\\afukaya\\OneDrive\\Source_Files\\R Files\\Covid19\\Datasets')

driver = webdriver.Firefox(executable_path = "D:\\Tools\\webdrivers\\geckodriver-v0.26.0-win64\\geckodriver.exe",
                           firefox_profile=firefoxprefs)

driver.get('https://covid.saude.gov.br/')
time.sleep(5)

driver.find_element_by_xpath('/html/body/app-root/ion-app/ion-router-outlet/app-home/ion-content/div[1]/div[2]/ion-button').click()

from selenium import webdriver

driver = webdriver.Firefox(executable_path= "/opt/geckodriver/geckodriver")

chave = "Python"

driver.get("https:\\www.apinfo.com")
print("Tile: ", driver.title)
print("ULR: ", driver.current_url)

driver.find_element_by_xpath('//*[@id="i-busca"]').send_keys(chave)
driver.find_element_by_xpath('//*[@id="btn-busca"]').click()

pagina = 1
pag_max = int(driver.find_element_by_class_name("n-paginas").text.split()[-1])

while pagina <= pag_max:
    vagas = driver.find_elements_by_class_name("texto")
    for vaga in vagas:
        print("Detalhes: ",vaga.text)
    print()
    pagina = pagina +1
    driver.find_element_by_xpath('/html/body/div[4]/div[2]/div/section/form/div/div[2]/table/tbody/tr/td[5]/input').click()

driver.close()

#driver.quit()